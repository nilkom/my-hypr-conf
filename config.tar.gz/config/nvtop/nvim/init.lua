require("config")
require("keymappings")
require("tokyonight").load()
